<img src="https://layanan.diskominfo.kaltaraprov.go.id/logokaltarafix.png" alt="Logo Kaltara" class="w-20 h-auto mx-auto">
